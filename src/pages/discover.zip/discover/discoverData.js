import cs2Gaming from '../../assets/images/csgo-gameplay-img.webp'
import gamingImg1 from '../../assets/images/comic-con-superhero-01.webp'


const discoverData = [
    {
      id: 1,
      image: cs2Gaming,
     
    },
    {
      id: 2,
      image: gamingImg1,
     
    },
    {
      id: 3,
      image: 'https://via.placeholder.com/400',
    
    },
    {
      id: 4,
      image: 'https://via.placeholder.com/400',
      
    },
    {
      id: 5,
      image: 'https://via.placeholder.com/400',
  
    },
    {
      id: 6,
      image: 'https://via.placeholder.com/400',
  
    },
    
  ];

  export default discoverData;