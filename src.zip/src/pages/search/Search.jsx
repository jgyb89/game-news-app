// Search.jsx
import React from 'react';
import { useModal } from '../../ModalContext';

const Search = () => {
  const { showModal } = useModal();

  return (
    <button onClick={showModal}>
      Search
    </button>
  );
};

export default Search;
