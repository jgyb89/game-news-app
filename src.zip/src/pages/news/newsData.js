import cs2Gaming from '../../assets/images/csgo-gameplay-img.webp';

const newsData = [
  {
    id: 1,
    title: 'Test Title',
    image: cs2Gaming || 'default-image-path.jpg',
    description: 'This is the description for the first post.',
  },
  {
    id: 2,
    title: 'Another Title',
    image: cs2Gaming || 'default-image-path.jpg',
    description: 'This is the description for the second post.',
  },
];

export default newsData;
