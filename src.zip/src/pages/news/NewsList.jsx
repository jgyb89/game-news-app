import NewsContent from "./NewsContent";
import newsData from "./newsData";
import "./NewsList.scss";

const NewsList = () => {
  return (
    <div className="news-list">
      {newsData && newsData.length > 0 ? (
        newsData.map((news) => (
          <NewsContent
            key={news.id}
            image={news.image}
            title={news.title}
            description={news.description}
          />
        ))
      ) : (
        <p className="no-news">No news articles available.</p>
      )}
    </div>
  );
};

export default NewsList;
