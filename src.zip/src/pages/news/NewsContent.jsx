import React from "react";
import { Card, CardBody, CardImg, CardTitle } from "reactstrap";
import "./News.scss";

const NewsContent = ({ image, title, description }) => {
  return (
    <div>
      <Card className="news-box">
        <CardBody>
          {image ? (
            <CardImg className="news-img">
              <img src={image} alt={title || "News"} />
            </CardImg>
          ) : (
            <p>Image unavailable</p>
          )}
          <CardTitle>
            <h3>{title || "Untitled News"}</h3>
            <p>{description || "No description available."}</p>
          </CardTitle>
        </CardBody>
      </Card>
    </div>
  );
};

export default NewsContent;
