const Create = () => {
  return (
    <div>Create</div>
  )
}

export default Create;