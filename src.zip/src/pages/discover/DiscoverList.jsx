import discoverData from './discoverData';
import './DiscoverList.scss';

const DiscoverList = () => {
  return (
    <div className="container">
      {discoverData.map((item, index) => (
        <div key={item.id} className={`tile tile-${index + 1}`}>
          <img src={item.image} alt={`Tile ${item.id}`} />
        </div>
      ))}
    </div>
  );
};

export default DiscoverList;
