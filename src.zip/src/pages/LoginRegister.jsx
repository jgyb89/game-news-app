import React from 'react'

export const LoginRegister = () => {
  return (
    <div>login</div>
  )
}

export default LoginRegister;