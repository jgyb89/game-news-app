import React, { useState } from 'react';

const Notifications = () => {
  return (
    <div>
      <h2>Notifications</h2>
    <p>Keep celebrating Cinema, I'm sure samson can be spleed without a </p>
    </div>
  )
}

export default Notifications;