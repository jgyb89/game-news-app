import React, { useState } from 'react';

const Notifications = () => {
  return (
    <div>Notifications</div>
  )
}

export default Notifications;