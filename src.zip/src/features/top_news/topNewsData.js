const topNews = [
    {
        id: 1,
        image: 'https://www.pngkey.com/png/detail/233-2332677_image-500580-placeholder-transparent.png',
        title: 'Latest game is gaining raving reviews - Top ten games of 2024',
    },
    {
        id: 2,
        image: 'https://www.pngkey.com/png/detail/233-2332677_image-500580-placeholder-transparent.png',
        title: 'Nvidia reveals latest RTX 5090 specs',
    },
    {
        id: 3,
        image: 'https://www.pngkey.com/png/detail/233-2332677_image-500580-placeholder-transparent.png',
        title: 'Antara is sexy',
    }
]

export default topNews;